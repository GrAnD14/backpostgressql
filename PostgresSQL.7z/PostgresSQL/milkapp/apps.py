from django.apps import AppConfig


class MilkappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'milkapp'
